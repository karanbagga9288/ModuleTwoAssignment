document.getElementById("Btn").addEventListener('click', function (e) {
  e.preventDefault();
  document.getElementById("goalListHeading").textContent = "List of added goals";
  let input = document.getElementById("goal").value;
  let li = document.createElement("li");
  if (input !== '') {
    li.innerHTML = `<span class='goalText'> ${input}</span> <button class='markCompleted'>Complete goal</button>`;
    let ol = document.getElementById("goalList");
    ol.appendChild(li);
  }
})

let olEl = document.getElementById("goalList");
olEl.addEventListener('click', function (e) {
  e.preventDefault();
  if (e.target.classList.contains('deleteMe')) {
    e.target.parentElement.remove();
  }
})

olEl.addEventListener('click', function (e) {
  e.preventDefault();
  if (e.target.classList.contains('markCompleted')) {
    e.target.parentElement.remove();
    document.getElementById("compGoalListHeading").textContent = "List of Completed goals (items)";
    let li = document.createElement("li");
    li.innerHTML = `<span class='completedGoalsItems'>${e.target.previousElementSibling.textContent}</span> <button class='deleteCompleted'> Delete completed goal </button>`;
    let ol = document.getElementById("compGoalList");
    ol.appendChild(li);
  }
})

let olElComp = document.getElementById("compGoalList");
olElComp.addEventListener('click', function (e) {
  e.preventDefault();
  if (e.target.classList.contains('deleteCompleted')) {
    e.target.parentElement.remove();
  }
})